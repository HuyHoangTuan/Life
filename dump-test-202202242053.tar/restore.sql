--
-- NOTE:
--
-- File paths need to be edited. Search for $$PATH$$ and
-- replace it with the path to the directory containing
-- the extracted data files.
--
--
-- PostgreSQL database dump
--

-- Dumped from database version 12.4
-- Dumped by pg_dump version 12.4

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

DROP DATABASE test;
--
-- Name: test; Type: DATABASE; Schema: -; Owner: -
--

CREATE DATABASE test WITH TEMPLATE = template0 ENCODING = 'UTF8' LC_COLLATE = 'English_United States.1252' LC_CTYPE = 'English_United States.1252';


\connect test

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: public; Type: SCHEMA; Schema: -; Owner: -
--

CREATE SCHEMA public;


--
-- Name: SCHEMA public; Type: COMMENT; Schema: -; Owner: -
--

COMMENT ON SCHEMA public IS 'standard public schema';


SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: account; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.account (
    id integer NOT NULL,
    display_name character varying(100) NOT NULL,
    email character varying(255) NOT NULL,
    password character varying(100) NOT NULL,
    avatar_path text,
    role smallint NOT NULL,
    active boolean DEFAULT true NOT NULL
);


--
-- Name: account_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.account_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: account_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.account_id_seq OWNED BY public.account.id;


--
-- Name: album; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.album (
    id integer NOT NULL,
    title character varying(100) NOT NULL,
    artist_id integer NOT NULL,
    release_date date NOT NULL,
    type integer NOT NULL,
    active boolean DEFAULT true NOT NULL
);


--
-- Name: album_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.album_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: album_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.album_id_seq OWNED BY public.album.id;


--
-- Name: comment; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.comment (
    id integer NOT NULL,
    playlist_id integer,
    album_id integer,
    creator_id integer NOT NULL,
    created_timestamp date DEFAULT CURRENT_TIMESTAMP NOT NULL,
    content text NOT NULL,
    active boolean DEFAULT true NOT NULL
);


--
-- Name: comment_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.comment_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: comment_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.comment_id_seq OWNED BY public.comment.id;


--
-- Name: favorite_album; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.favorite_album (
    id integer NOT NULL,
    creator_id integer NOT NULL,
    album_id integer NOT NULL,
    active boolean DEFAULT true NOT NULL
);


--
-- Name: favorite_album_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.favorite_album_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: favorite_album_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.favorite_album_id_seq OWNED BY public.favorite_album.id;


--
-- Name: favorite_artist; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.favorite_artist (
    id integer NOT NULL,
    creator_id integer NOT NULL,
    artist_id integer NOT NULL,
    active boolean DEFAULT true NOT NULL
);


--
-- Name: favorite_artist_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.favorite_artist_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: favorite_artist_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.favorite_artist_id_seq OWNED BY public.favorite_artist.id;


--
-- Name: favorite_song; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.favorite_song (
    id integer NOT NULL,
    creator_id integer NOT NULL,
    song_id integer NOT NULL,
    active boolean DEFAULT true NOT NULL
);


--
-- Name: favorite_song_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.favorite_song_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: favorite_song_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.favorite_song_id_seq OWNED BY public.favorite_song.id;


--
-- Name: playlist; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.playlist (
    id integer NOT NULL,
    creator_id integer NOT NULL,
    active boolean DEFAULT true NOT NULL,
    title text
);


--
-- Name: playlist_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.playlist_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: playlist_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.playlist_id_seq OWNED BY public.playlist.id;


--
-- Name: playlist_song; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.playlist_song (
    id integer NOT NULL,
    playlist_id integer NOT NULL,
    song_id integer NOT NULL,
    added_date date DEFAULT CURRENT_DATE NOT NULL,
    active boolean DEFAULT true NOT NULL
);


--
-- Name: playlist_song_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.playlist_song_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: playlist_song_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.playlist_song_id_seq OWNED BY public.playlist_song.id;


--
-- Name: song; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.song (
    id integer NOT NULL,
    album_id integer NOT NULL,
    track_num integer NOT NULL,
    track_name character varying(100) NOT NULL,
    active boolean DEFAULT true NOT NULL
);


--
-- Name: song_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.song_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: song_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.song_id_seq OWNED BY public.song.id;


--
-- Name: test; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.test (
    user_name character varying(100)
);


--
-- Name: account id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.account ALTER COLUMN id SET DEFAULT nextval('public.account_id_seq'::regclass);


--
-- Name: album id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.album ALTER COLUMN id SET DEFAULT nextval('public.album_id_seq'::regclass);


--
-- Name: comment id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.comment ALTER COLUMN id SET DEFAULT nextval('public.comment_id_seq'::regclass);


--
-- Name: favorite_album id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.favorite_album ALTER COLUMN id SET DEFAULT nextval('public.favorite_album_id_seq'::regclass);


--
-- Name: favorite_artist id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.favorite_artist ALTER COLUMN id SET DEFAULT nextval('public.favorite_artist_id_seq'::regclass);


--
-- Name: favorite_song id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.favorite_song ALTER COLUMN id SET DEFAULT nextval('public.favorite_song_id_seq'::regclass);


--
-- Name: playlist id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.playlist ALTER COLUMN id SET DEFAULT nextval('public.playlist_id_seq'::regclass);


--
-- Name: playlist_song id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.playlist_song ALTER COLUMN id SET DEFAULT nextval('public.playlist_song_id_seq'::regclass);


--
-- Name: song id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.song ALTER COLUMN id SET DEFAULT nextval('public.song_id_seq'::regclass);


--
-- Data for Name: account; Type: TABLE DATA; Schema: public; Owner: -
--

\i $$PATH$$/2923.dat

--
-- Data for Name: album; Type: TABLE DATA; Schema: public; Owner: -
--

\i $$PATH$$/2925.dat

--
-- Data for Name: comment; Type: TABLE DATA; Schema: public; Owner: -
--

\i $$PATH$$/2933.dat

--
-- Data for Name: favorite_album; Type: TABLE DATA; Schema: public; Owner: -
--

\i $$PATH$$/2939.dat

--
-- Data for Name: favorite_artist; Type: TABLE DATA; Schema: public; Owner: -
--

\i $$PATH$$/2935.dat

--
-- Data for Name: favorite_song; Type: TABLE DATA; Schema: public; Owner: -
--

\i $$PATH$$/2937.dat

--
-- Data for Name: playlist; Type: TABLE DATA; Schema: public; Owner: -
--

\i $$PATH$$/2929.dat

--
-- Data for Name: playlist_song; Type: TABLE DATA; Schema: public; Owner: -
--

\i $$PATH$$/2931.dat

--
-- Data for Name: song; Type: TABLE DATA; Schema: public; Owner: -
--

\i $$PATH$$/2927.dat

--
-- Data for Name: test; Type: TABLE DATA; Schema: public; Owner: -
--

\i $$PATH$$/2940.dat

--
-- Name: account_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.account_id_seq', 5, true);


--
-- Name: album_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.album_id_seq', 2, true);


--
-- Name: comment_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.comment_id_seq', 1, true);


--
-- Name: favorite_album_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.favorite_album_id_seq', 1, true);


--
-- Name: favorite_artist_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.favorite_artist_id_seq', 2, true);


--
-- Name: favorite_song_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.favorite_song_id_seq', 1, false);


--
-- Name: playlist_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.playlist_id_seq', 4, true);


--
-- Name: playlist_song_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.playlist_song_id_seq', 2, true);


--
-- Name: song_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.song_id_seq', 26, true);


--
-- Name: account account_email_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.account
    ADD CONSTRAINT account_email_key UNIQUE (email);


--
-- Name: account account_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.account
    ADD CONSTRAINT account_pkey PRIMARY KEY (id);


--
-- Name: album album_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.album
    ADD CONSTRAINT album_pkey PRIMARY KEY (id);


--
-- Name: comment comment_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.comment
    ADD CONSTRAINT comment_pkey PRIMARY KEY (id);


--
-- Name: favorite_album favorite_album_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.favorite_album
    ADD CONSTRAINT favorite_album_pkey PRIMARY KEY (id);


--
-- Name: favorite_artist favorite_artist_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.favorite_artist
    ADD CONSTRAINT favorite_artist_pkey PRIMARY KEY (id);


--
-- Name: favorite_song favorite_song_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.favorite_song
    ADD CONSTRAINT favorite_song_pkey PRIMARY KEY (id);


--
-- Name: playlist playlist_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.playlist
    ADD CONSTRAINT playlist_pkey PRIMARY KEY (id);


--
-- Name: playlist_song playlist_song_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.playlist_song
    ADD CONSTRAINT playlist_song_pkey PRIMARY KEY (id);


--
-- Name: song song_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.song
    ADD CONSTRAINT song_pkey PRIMARY KEY (id);


--
-- Name: song fk_album_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.song
    ADD CONSTRAINT fk_album_id FOREIGN KEY (album_id) REFERENCES public.album(id);


--
-- Name: comment fk_album_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.comment
    ADD CONSTRAINT fk_album_id FOREIGN KEY (album_id) REFERENCES public.album(id);


--
-- Name: album fk_artist_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.album
    ADD CONSTRAINT fk_artist_id FOREIGN KEY (artist_id) REFERENCES public.account(id);


--
-- Name: favorite_artist fk_artist_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.favorite_artist
    ADD CONSTRAINT fk_artist_id FOREIGN KEY (artist_id) REFERENCES public.account(id);


--
-- Name: favorite_album fk_artist_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.favorite_album
    ADD CONSTRAINT fk_artist_id FOREIGN KEY (album_id) REFERENCES public.album(id);


--
-- Name: playlist fk_creator_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.playlist
    ADD CONSTRAINT fk_creator_id FOREIGN KEY (creator_id) REFERENCES public.account(id);


--
-- Name: comment fk_creator_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.comment
    ADD CONSTRAINT fk_creator_id FOREIGN KEY (creator_id) REFERENCES public.account(id);


--
-- Name: favorite_artist fk_creator_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.favorite_artist
    ADD CONSTRAINT fk_creator_id FOREIGN KEY (creator_id) REFERENCES public.account(id);


--
-- Name: favorite_song fk_creator_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.favorite_song
    ADD CONSTRAINT fk_creator_id FOREIGN KEY (creator_id) REFERENCES public.account(id);


--
-- Name: favorite_album fk_creator_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.favorite_album
    ADD CONSTRAINT fk_creator_id FOREIGN KEY (creator_id) REFERENCES public.account(id);


--
-- Name: playlist_song fk_playlist_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.playlist_song
    ADD CONSTRAINT fk_playlist_id FOREIGN KEY (playlist_id) REFERENCES public.playlist(id);


--
-- Name: comment fk_playlist_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.comment
    ADD CONSTRAINT fk_playlist_id FOREIGN KEY (playlist_id) REFERENCES public.playlist(id);


--
-- Name: playlist_song fk_song_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.playlist_song
    ADD CONSTRAINT fk_song_id FOREIGN KEY (song_id) REFERENCES public.song(id);


--
-- Name: favorite_song fk_song_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.favorite_song
    ADD CONSTRAINT fk_song_id FOREIGN KEY (song_id) REFERENCES public.song(id);


--
-- PostgreSQL database dump complete
--

